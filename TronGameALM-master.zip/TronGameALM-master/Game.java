package tronGame;
import javax.swing.JFrame;


public class Game extends JFrame {
	public final static int WIDTH = 1000, HEIGHT = 800;
	
	private static final long serialVersionUID = 1L;
    public GamePanel panel;

    public Game() {
        setSize(WIDTH, HEIGHT);
        setTitle("Tron Game by Alex, Mateo, Logan, Ethan");
        
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        panel = new GamePanel();
        add(panel);

        panel.setVisible(true);
        validate();
    }

    public GamePanel getPanel() {
        return panel;
    }

    public static void main(String[] args) {
        new Game();
    }
}
