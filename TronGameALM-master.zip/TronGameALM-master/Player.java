package tronGame;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;

public class Player {
    private static final int WIDTH = 10, HEIGHT = 10, DIRECTION = 1;

    private int upKey, downKey, leftKey, rightKey;
	private int x, xa;
    private int y, ya;

    public ArrayList<Rectangle> trailRects = new ArrayList<Rectangle>();
    
	private Color color;

    public Player(int upKey, int downKey, int leftKey, int rightKey, int x, Color color) {
        this.x = x;
        this.y = Game.HEIGHT / 2;
        
        this.upKey = upKey;
        this.downKey = downKey;
        this.leftKey = leftKey;
        this.rightKey = rightKey;
        
        this.color = color;        
    }

    public void updatePosition() {
        if (y > 0 && y < Game.HEIGHT - HEIGHT - 29) {
            y += ya;
        }
        else if (y == 0) {
            y++;
        }
        else if (y == Game.HEIGHT - HEIGHT - 29) {
            y--;
        }
        
        if(x > 0 && x < Game.WIDTH - WIDTH) {
        	x += xa;
        }
        else if (x == 0) {
            x++;
        }
        else if (x == Game.WIDTH - WIDTH) {
            x--;
        }

        Rectangle currentRect = new Rectangle(x, y, WIDTH, HEIGHT);
        trailRects.add(currentRect);
    }

    public void keyPressed(int keyCode) {
        if (keyCode == upKey && ya == 0){
        	xa = 0;
        	ya = -(DIRECTION);
        }
        else if (keyCode == downKey && ya == 0) {
        	xa = 0;
        	ya = DIRECTION;
        }
        else if (keyCode == leftKey && xa == 0) {
        	ya = 0;
        	xa = -(DIRECTION);
        } 	
        else if (keyCode == rightKey && xa == 0) {
        	ya = 0;
        	xa = DIRECTION;
        }
    }	

    public void released(int keyCode) {

    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }

    public void paint(Graphics g) {
        g.setColor(color);
    	g.fillRect(x, y, WIDTH, HEIGHT);	
    	/*
    	for (int i = 0; i < trailRects.size(); i++) {
    		Rectangle rect = trailRects.get(i);
        	g.fillRect(rect.x, rect.y, rect.width, rect.height);	
    	}
    	*/
    }

    public void reset() {    	
    	trailRects = new ArrayList<Rectangle>();
        this.y = Game.HEIGHT / 2;
    }
    
	public int getY() {
		return y;
	}
	
	public int getX() {
		return x;
	}

	public void setXA(int xa) {
		this.xa = xa;
	}

	public void setYA(int ya) {
		this.ya = ya;		
	}

	public void setX(int x) {
		this.x = x;		
	}
	
	public void setY(int y) {
		this.y = y;		
	}
	
	public Rectangle getCurrentPosition() {
		return new Rectangle(this.getX(), this.getY(), WIDTH, HEIGHT);
	}
	
	public ArrayList<Rectangle> getTrailRectangles() {
		return this.trailRects;
	}
}

