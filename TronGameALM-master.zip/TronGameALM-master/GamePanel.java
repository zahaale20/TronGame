package tronGame;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
	private static final long serialVersionUID = 1L;
	private static int OUTSIDEWALL_X = 985;
	private static int OUTSIDEWALL_Y = 755;

	private static int PLAYER1_STARTX = Game.WIDTH - 45;
	private static int PLAYER2_STARTX = 20;

    private Player player1, player2;
    private int winner;
    
    private int scorePlayer1 = 0;
    private int scorePlayer2 = 0;
    
    private Timer timer;
    
    private static final int DIRECTION = 1;
    
    private JButton newRoundButton;
    private JButton quitButton;
    private JButton resetScoreButton;
    
    private JLabel scoreLabel1, scoreLabel2;
    private JLabel winnerLabel;
    
    private Image img;;
    
    private boolean started = false;
    
    public GamePanel() {		
    	scoreLabel2 = new JLabel(Integer.toString(scorePlayer2));
    	scoreLabel2.setFont(new Font("Calibri", Font.PLAIN , 40));
    	scoreLabel2.setForeground(Color.RED);
    	add(scoreLabel2);
    	
    	scoreLabel1 = new JLabel(Integer.toString(scorePlayer1));
    	scoreLabel1.setFont(new Font("Calibri", Font.PLAIN , 40));
    	scoreLabel1.setForeground(Color.BLUE);
    	add(scoreLabel1);
    	
    	Random rand = new Random();
    	int num = rand.nextInt(9);
    	String background = "src/images/background" + num + ".PNG";

    	try {
			img = ImageIO.read(new File(background));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	setBackground(Color.GRAY);
    	
        newRoundButton = new JButton("New Round");
        newRoundButton.setFont(new Font("Calibri", Font.PLAIN, 40));
    	newRoundButton.addActionListener(this);
    	newRoundButton.setEnabled(false);
    	newRoundButton.addActionListener(this);
    	newRoundButton.setEnabled(true);
    	add(newRoundButton);
    	
    	resetScoreButton = new JButton("Reset Score");
    	resetScoreButton.setFont(new Font("Calibri", Font.PLAIN, 40));
    	resetScoreButton.addActionListener(this);
    	add(resetScoreButton);
    	
    	quitButton = new JButton("Quit");
        quitButton.setFont(new Font("Calibri", Font.PLAIN, 40));
    	quitButton.addActionListener(this);
    	add(quitButton);
    	
    	winnerLabel = new JLabel();
    	winnerLabel.setVisible(false);
    	winnerLabel.setForeground(Color.WHITE);
    	winnerLabel.setFont(new Font("Calibri", Font.PLAIN , 40));
    	add(winnerLabel);
    	
        // instantiate 2 players
        player1 = new Player(KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, PLAYER1_STARTX, Color.BLUE);
        player2 = new Player(KeyEvent.VK_W, KeyEvent.VK_S, KeyEvent.VK_A, KeyEvent.VK_D, PLAYER2_STARTX, Color.RED);
    	
        // players start moving in opposite direction towards each other
        player1.setXA(-DIRECTION);
    	player2.setXA(DIRECTION);
        
        addKeyListener(this);
        setFocusable(true);
        setVisible(true);
    }

    public Player getPlayer(int playerNo) {
        if (playerNo == 1)
            return player1;
        else
            return player2;
    }

    private void updatePositions() {
        player1.updatePosition();
        player2.updatePosition();
        
        if (player1.getY() <= 0 || player1.getY() >= OUTSIDEWALL_Y || player1.getX() <= 0 || player1.getX() >= OUTSIDEWALL_X ) {
        	stopGame();
        	player2Win();
        }
        
        if (player2.getY() <= 0 || player2.getY() >= OUTSIDEWALL_Y || player2.getX() <= 0 || player2.getX() >= OUTSIDEWALL_X) {
        	stopGame();
        	player1Win();
        }
        
        int collision = checkCollision(player1, player2);    
        // -1 if tie, 1 if player1 wins and 2 if player 2 wins
        if (collision != 0) {
        	stopGame();
        	if (collision == -1) {
        		tie();
        	}
        	if (collision == 1) {
        		player1Win();
        	}
        	if (collision == 2) {
        		player2Win();
        	}
        }
		this.player1.paint(this.getGraphics());
		this.player2.paint(this.getGraphics());
    }

    public void actionPerformed(ActionEvent e) {
    	if (started) {
    		updatePositions();
    	}
    	
        if (e.getActionCommand() != null && e.getActionCommand().equalsIgnoreCase("new round")) {
        	started = true;
        	// reset start positions
        	resetPlayers();
        	
        	// set focus in game window after restart
            requestFocusInWindow();
            
            // start timer
            if (this.timer != null) {
            	timer.restart();
            } else {
            	timer = new Timer(5, this);
            	timer.start();
            }
        }
        
        if (e.getActionCommand() != null && e.getActionCommand().equalsIgnoreCase("reset score")) {
        	scorePlayer1 = 0;
        	scorePlayer2 = 0;
        	scoreLabel1.setText(Integer.toString(scorePlayer1));
        	scoreLabel2.setText(Integer.toString(scorePlayer2));
        	winnerLabel.setText("");
        }
        
        if (e.getActionCommand() != null && e.getActionCommand().equalsIgnoreCase("quit")) {
        	System.exit(0);
        }
    }

    public void keyPressed(KeyEvent e) {
        player1.keyPressed(e.getKeyCode());
        player2.keyPressed(e.getKeyCode());
    }

    public void keyReleased(KeyEvent e) {
        player1.released(e.getKeyCode());
        player2.released(e.getKeyCode());
    }

    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(img, 0, 0, null );
        player1.paint(g);
        player2.paint(g);
    }
    
    private void resetPlayers() {
    	player1.reset();
    	player2.reset();
    	
    	player1.setX(PLAYER1_STARTX);
    	player2.setX(PLAYER2_STARTX);

    	player1.setY(Game.HEIGHT / 2);
    	player2.setY(Game.HEIGHT / 2);
    	
    	player1.setXA(-DIRECTION);
    	player2.setXA(DIRECTION);
    	
    	player1.setYA(0);
    	player2.setYA(0);
    }
    
    public void stopGame() {  
    	this.timer.stop();
    	resetPlayers();
    	repaint();
    }
    
    public void tie() {
    	setWinner(0);
    	setScore1(getScore1() + 1);
    	setScore2(getScore2() + 1);
    	winnerLabel.setForeground(Color.WHITE);
    	winnerLabel.setText("Tie.");
    	winnerLabel.setVisible(true);
        scoreLabel1.setText(Integer.toString(scorePlayer1));
        scoreLabel2.setText(Integer.toString(scorePlayer2));
        newRoundButton.setVisible(true);
    }
    
    public void player1Win() {
    	setWinner(1);
    	setScore1(getScore1() + 1);
    	winnerLabel.setForeground(Color.BLUE);
    	winnerLabel.setText("Blue Wins.");
    	winnerLabel.setVisible(true);
        scoreLabel1.setText(Integer.toString(scorePlayer1));
        newRoundButton.setVisible(true);
    }
    
    public void player2Win() {
    	setWinner(2);
    	setScore2(getScore2() + 1);
    	winnerLabel.setForeground(Color.RED);
    	winnerLabel.setText("Red Wins.");
    	winnerLabel.setVisible(true);
        scoreLabel2.setText(Integer.toString(scorePlayer2));
        newRoundButton.setVisible(true);
    }
    
    // return -1 if tie, 1 if player1 wins and 2 if player 2 wins
    public int checkCollision(Player player1, Player player2) {
    	int collision = 0;
    	
        if (player1.getCurrentPosition().intersects(player2.getCurrentPosition())) {
        	// tie
        	collision = -1;
        }
        
        if (collision == 0) {
        	Rectangle player1Position = player1.getCurrentPosition();
    		Rectangle player2Position = player2.getCurrentPosition();
    		
    		ArrayList<Rectangle> player1Trail = player1.getTrailRectangles();
    		ArrayList<Rectangle> player2Trail = player2.getTrailRectangles();
    		
        	if (player2Trail.contains(player1Position)) {
        		// player 2 wins
        		collision = 2;
        	}
        	
        	// if player 2 contains hit its own trail
        	if (player2Trail.indexOf(player2Position)> 0 && player2Trail.indexOf(player2Position) < player2Trail.size() - 1) {
        		// player 1 wins
        		collision = 1;
        	}
        	
        	if (collision == 0) {
            	if (player1Trail.contains(player2Position)) {
            		// player 1 wins
            		collision = 1;
            	}
            	
               	if (player1Trail.indexOf(player1Position)> 0 && player1Trail.indexOf(player1Position) < player2Trail.size() - 1) {
               	    // player 2 wins
            		collision = 2;
            	}
        	}
        }
        return collision;
    }

	public int getWinner() {
		return winner;
	}

	public void setWinner(int winner) {
		this.winner = winner;
	}

	public int getScore1() {
		return scorePlayer1;
	}

	public void setScore1(int score1) {
		this.scorePlayer1 = score1;
	}

	public int getScore2() {
		return scorePlayer2;
	}

	public void setScore2(int score2) {
		this.scorePlayer2 = score2;
	}
}
